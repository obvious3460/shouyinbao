'use strict';
/* ============================================================
 * 收银宝 —— 收银 · 记账 · VIP 会员系统
 * 纯前端实现，数据保存在浏览器 localStorage
 * ============================================================ */

const LS_KEY = 'shouyinbao_v1';
const $  = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

/* ---------- 工具函数 ---------- */
function pad(n){ return String(n).padStart(2, '0'); }
function round2(n){ return Math.round((n + Number.EPSILON) * 100) / 100; }
function money(n){ return '¥' + round2(n).toFixed(2); }
function esc(s){ return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
function uid(p){ return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function todayStr(){ const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
function fmtDT(ts){ const d = new Date(ts); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function fmtD(ts){ const d = new Date(ts); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
function inRange(ts, from, to){
  const ds = fmtD(ts);
  if (from && ds < from) return false;
  if (to && ds > to) return false;
  return true;
}
function levelName(lid){ const l = state.levels.find(x => x.id === lid); return l ? l.name : '未知'; }
function levelRate(lid){ const l = state.levels.find(x => x.id === lid); return l ? l.rate : 1; }

/* ---------- 数据层 ---------- */
function defaultState(){
  return {
    shopName: '收银宝便利店',
    cashier: '收银员',
    levels: [
      { id: 'l1', name: '普通会员', rate: 0.98 },
      { id: 'l2', name: '银卡会员', rate: 0.95 },
      { id: 'l3', name: '金卡会员', rate: 0.92 },
      { id: 'l4', name: '黑金会员', rate: 0.88 }
    ],
    products: [
      { id: 'p1', name: '可口可乐', category: '饮料', price: 3.00, cost: 2.10, stock: 120, unit: '瓶' },
      { id: 'p2', name: '农夫山泉', category: '饮料', price: 2.00, cost: 1.20, stock: 200, unit: '瓶' },
      { id: 'p3', name: '鲜牛奶', category: '饮料', price: 6.50, cost: 4.80, stock: 60, unit: '盒' },
      { id: 'p4', name: '薯片', category: '零食', price: 6.00, cost: 3.60, stock: 80, unit: '袋' },
      { id: 'p5', name: '面包', category: '零食', price: 5.00, cost: 2.80, stock: 45, unit: '个' },
      { id: 'p6', name: '红烧牛肉面', category: '零食', price: 4.00, cost: 2.50, stock: 90, unit: '桶' },
      { id: 'p7', name: '红富士苹果', category: '生鲜', price: 8.80, cost: 5.50, stock: 25, unit: '斤' },
      { id: 'p8', name: '香蕉', category: '生鲜', price: 5.60, cost: 3.20, stock: 30, unit: '斤' },
      { id: 'p9', name: '抽纸', category: '日用品', price: 12.00, cost: 8.50, stock: 40, unit: '提' },
      { id: 'p10', name: '牙膏', category: '日用品', price: 15.00, cost: 10.00, stock: 35, unit: '支' },
      { id: 'p11', name: '洗洁精', category: '日用品', price: 8.00, cost: 5.20, stock: 0, unit: '瓶' }
    ],
    members: [
      { id: 'm1', name: '张三', phone: '13800000001', levelId: 'l3', points: 1280, createdAt: Date.now() - 86400000 * 30 },
      { id: 'm2', name: '李四', phone: '13800000002', levelId: 'l1', points: 350, createdAt: Date.now() - 86400000 * 10 },
      { id: 'm3', name: '王五', phone: '13800000003', levelId: 'l4', points: 5660, createdAt: Date.now() - 86400000 * 60 }
    ],
    sales: [],
    expenses: [
      { id: 'e1', time: Date.now() - 86400000 * 2, category: '进货', amount: 1560.00, note: '日用品补货' },
      { id: 'e2', time: Date.now() - 86400000 * 1, category: '水电', amount: 320.50, note: '上月水电费' }
    ],
    settings: { pointsPerYuan: 1, pointsToYuan: 100, lowStock: 10 },
    seq: 1000
  };
}

let state;
function load(){
  try{
    const raw = localStorage.getItem(LS_KEY);
    if (raw){
      const s = JSON.parse(raw);
      const def = defaultState();
      // 合并，保证新字段有默认值
      const merged = Object.assign({}, def, s);
      merged.settings = Object.assign({}, def.settings, s.settings || {});
      return merged;
    }
  }catch(e){ console.warn('数据加载失败，使用默认数据', e); }
  return defaultState();
}
function save(){ localStorage.setItem(LS_KEY, JSON.stringify(state)); }

/* ---------- 视图切换 ---------- */
const PAGE_TITLES = {
  home: '📊 今日概览', pos: '🛒 收银台', products: '📦 商品管理', members: '👤 会员管理',
  expenses: '💸 出账记账', ledger: '📒 流水账本', stats: '📈 统计分析', settings: '⚙️ 系统设置'
};
function switchView(name){
  $$('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.view === name));
  $$('.view').forEach(el => el.style.display = 'none');
  const v = $('#view-' + name);
  if (v) v.style.display = 'block';
  $('#pageTitle').textContent = PAGE_TITLES[name] || '';
  const renders = {
    home: renderHome, pos: renderPos, products: renderProducts, members: renderMembers,
    expenses: renderExpenses, ledger: renderLedger, stats: renderStats, settings: renderSettings
  };
  if (renders[name]) renders[name]();
}
function openModal(id){ $(id).classList.add('show'); }
function closeModal(id){ $(id).classList.remove('show'); }

/* ============================================================
 * 首页概览
 * ============================================================ */
function renderHome(){
  $('#todayLabel').textContent = todayStr() + ' ' + state.shopName;
  const today = todayStr();
  const sales = state.sales.filter(s => inRange(s.time, today, today));
  const exps  = state.expenses.filter(e => inRange(e.time, today, today));
  const revenue = round2(sales.reduce((a, s) => a + s.payable, 0));
  const expense = round2(exps.reduce((a, e) => a + e.amount, 0));
  $('#homeOrders').textContent = sales.length;
  $('#homeRevenue').textContent = money(revenue);
  $('#homeExpense').textContent = money(expense);
  $('#homeNet').textContent = money(revenue - expense);

  // 库存预警
  const low = state.products.filter(p => p.stock >= 0 && p.stock <= state.settings.lowStock);
  $('#homeWarn').innerHTML = low.length
    ? low.map(p => `<div class="warn-item"><span>${esc(p.name)}（${esc(p.category)}）</span><span class="st">库存 ${p.stock} ${esc(p.unit || '')}</span></div>`).join('')
    : '<div class="empty">✅ 库存充足，无预警</div>';

  // 最近流水（销售 + 支出，按时间倒序取 8 条）
  const rows = [
    ...state.sales.map(s => ({ time: s.time, kind: 'in', text: `销售 ${s.no}`, amt: s.payable, note: `${s.items.length} 件商品` })),
    ...state.expenses.map(e => ({ time: e.time, kind: 'out', text: `出账 · ${e.category}`, amt: -e.amount, note: e.note || '' }))
  ].sort((a, b) => b.time - a.time).slice(0, 8);
  $('#homeRecent').innerHTML = rows.length
    ? rows.map(r => `<div class="warn-item"><span>${fmtDT(r.time)}　${esc(r.text)}${r.note ? '　<small style="color:var(--muted)">' + esc(r.note) + '</small>' : ''}</span><span style="${r.kind === 'in' ? 'color:var(--ok)' : 'color:var(--danger)'}">${r.amt >= 0 ? '+' : ''}${money(Math.abs(r.amt))}</span></div>`).join('')
    : '<div class="empty">暂无流水记录</div>';
}

/* ============================================================
 * 收银台
 * ============================================================ */
let prodFilter = { kw: '', cat: '全部' };
let cart = [];
let cartMemberId = '';
let pointsUse = 0;
let manualDiscount = 100;
let payMethod = '微信';
let cashReceived = '';

function renderPos(){ renderProductGrid(); renderCart(); }

function renderProductGrid(){
  const cats = ['全部', ...new Set(state.products.map(p => p.category))];
  $('#catChips').innerHTML = cats.map(c =>
    `<div class="chip ${prodFilter.cat === c ? 'active' : ''}" onclick="prodFilter.cat=${JSON.stringify(c)};renderPos()">${esc(c)}</div>`).join('');

  const kw = prodFilter.kw.trim().toLowerCase();
  const list = state.products.filter(p =>
    (prodFilter.cat === '全部' || p.category === prodFilter.cat) &&
    (!kw || p.name.toLowerCase().includes(kw)));

  $('#posGrid').innerHTML = list.length ? list.map(p => {
    const out = p.stock === 0;
    const low = p.stock > 0 && p.stock <= state.settings.lowStock;
    return `<div class="pcard ${out ? 'out' : ''} ${low ? 'low' : ''}" ${out ? '' : `onclick="addToCart('${p.id}')"`} title="点击加入购物车">
      <div class="pname">${esc(p.name)}</div>
      <div class="pprice">${money(p.price)}</div>
      <div class="pstock">${p.stock < 0 ? '不限库存' : '库存 ' + p.stock} ${esc(p.unit || '')}</div>
    </div>`;
  }).join('') : '<div class="empty" style="grid-column:1/-1">没有找到商品，请到「商品管理」添加</div>';
}

function addToCart(pid){
  const p = state.products.find(x => x.id === pid);
  if (!p) return;
  if (p.stock === 0){ alert(`「${p.name}」已售罄`); return; }
  const item = cart.find(c => c.productId === pid);
  if (item){
    if (p.stock >= 0 && item.qty + 1 > p.stock){ alert(`「${p.name}」库存不足（剩余 ${p.stock}）`); return; }
    item.qty++;
  } else {
    cart.push({ productId: p.id, name: p.name, category: p.category, price: p.price, cost: p.cost, qty: 1, unit: p.unit });
  }
  renderCart();
}
function cartQty(pid, d){
  const item = cart.find(c => c.productId === pid);
  if (!item) return;
  const p = state.products.find(x => x.id === pid);
  item.qty += d;
  if (item.qty <= 0){ cart = cart.filter(c => c.productId !== pid); }
  else if (p && p.stock >= 0 && item.qty > p.stock){ alert(`「${p.name}」库存不足`); item.qty = p.stock; }
  renderCart();
}
function removeFromCart(pid){ cart = cart.filter(c => c.productId !== pid); renderCart(); }
function clearCart(){ if (cart.length && !confirm('确定清空购物车？')) return; cart = []; renderCart(); }

function onMemberChange(){
  cartMemberId = $('#memberSelect').value;
  pointsUse = 0;
  cashReceived = '';
  renderCart();
}
function onPayChange(){
  payMethod = $('#payMethod').value;
  cashReceived = '';
  renderCart();
}

/* ---------- 折扣计算核心 ----------
 * 计算顺序：小计 → 整单折扣 → VIP 额外折扣 → 积分抵扣 → 应收
 * VIP「额外折扣」指：在整单折扣的基础上，再按会员等级折扣率打折 */
function calcCart(member){
  const subtotal = round2(cart.reduce((a, c) => a + c.price * c.qty, 0));

  // 1) 整单折扣
  const manualRate = Math.min(100, Math.max(1, parseFloat(manualDiscount) || 100)) / 100;
  const afterManual = round2(subtotal * manualRate);
  const manualDiscountAmt = round2(subtotal - afterManual);

  // 2) VIP 额外折扣
  const rate = member ? levelRate(member.levelId) : 1;
  const vipDiscount = round2(afterManual - afterManual * rate);
  const afterVip = round2(afterManual * rate);

  // 3) 积分抵扣（每 pointsToYuan 积分抵 1 元，最高抵折后金额的 50%）
  let pu = Math.max(0, Math.floor(parseFloat(pointsUse) || 0));
  if (member) pu = Math.min(pu, member.points);
  const maxPointsValue = round2(afterVip * 0.5);
  const maxPoints = Math.floor(maxPointsValue * state.settings.pointsToYuan);
  pu = Math.min(pu, maxPoints);
  const pointsValue = round2(pu / state.settings.pointsToYuan);

  // 4) 应收
  const payable = Math.max(0, round2(afterVip - pointsValue));
  const pointsEarned = Math.floor(payable * state.settings.pointsPerYuan);

  return { subtotal, manualRate, manualDiscountAmt, vipRate: rate, vipDiscount, pointsUsed: pu, pointsValue, payable, pointsEarned, afterVip };
}

function renderCart(){
  // 会员下拉
  $('#memberSelect').innerHTML = '<option value="">非会员（不打折）</option>' +
    state.members.map(m => `<option value="${m.id}">${esc(m.name)}（${esc(levelName(m.levelId))} ${(levelRate(m.levelId) * 100).toFixed(0)}折）</option>`).join('');
  $('#memberSelect').value = cartMemberId;

  const member = cartMemberId ? state.members.find(m => m.id === cartMemberId) : null;
  $('#memberInfo').innerHTML = member
    ? `会员：${esc(member.name)}　等级：${esc(levelName(member.levelId))}（${(levelRate(member.levelId) * 100).toFixed(0)}折）　可用积分：${member.points}`
    : '未选择会员';

  const puInput = $('#pointsUse');
  puInput.disabled = !member;
  if (!member){ pointsUse = 0; puInput.value = 0; }
  $('#manualDiscount').value = manualDiscount;

  // 购物车列表
  $('#cartList').innerHTML = cart.length ? cart.map(c =>
    `<div class="cart-item">
      <div class="ci-name">${esc(c.name)}</div>
      <div class="qty-ctl">
        <button onclick="cartQty('${c.productId}',-1)">−</button>
        <span class="q">${c.qty}</span>
        <button onclick="cartQty('${c.productId}',1)">＋</button>
      </div>
      <div class="ci-price">${money(c.price * c.qty)}</div>
      <div class="ci-del" onclick="removeFromCart('${c.productId}')" title="移除">✕</div>
    </div>`).join('') : '<div class="empty">购物车为空，点击左侧商品加入</div>';

  // 汇总计算
  const s = calcCart(member);
  pointsUse = s.pointsUsed;
  puInput.value = pointsUse;

  $('#sumSubtotal').textContent = money(s.subtotal);
  $('#sumManualRow').style.display = s.manualDiscountAmt > 0.001 ? 'flex' : 'none';
  $('#sumManual').textContent = '-' + money(s.manualDiscountAmt);
  $('#sumRateLabel').textContent = member ? levelName(member.levelId) + ' ' + (s.vipRate * 100).toFixed(0) + '折' : '无';
  $('#sumVip').textContent = '-' + money(s.vipDiscount);
  $('#sumPoints').textContent = '-' + money(s.pointsValue);
  $('#sumPayable').textContent = money(s.payable);

  // 现金找零
  $('#cashRow').style.display = payMethod === '现金' ? 'block' : 'none';
  $('#cashReceived').value = cashReceived;
  if (payMethod === '现金'){
    const cash = parseFloat(cashReceived) || 0;
    $('#changeLabel').textContent = money(Math.max(0, round2(cash - s.payable)));
  }
}

/* ---------- 结算 ---------- */
function settle(){
  if (!cart.length){ alert('购物车为空，请先选择商品'); return; }
  const member = cartMemberId ? state.members.find(m => m.id === cartMemberId) : null;
  const s = calcCart(member);

  if (payMethod === '现金'){
    const cash = parseFloat(cashReceived) || 0;
    if (cash + 0.001 < s.payable){ alert(`实收现金不足：应收 ${money(s.payable)}`); return; }
  }

  const no = 'S' + todayStr().replace(/-/g, '') + '-' + String(state.seq++);
  const sale = {
    id: uid('s'), no, time: Date.now(),
    items: cart.map(c => ({ productId: c.productId, name: c.name, category: c.category, price: c.price, cost: c.cost, qty: c.qty })),
    subtotal: s.subtotal,
    manualRate: s.manualRate, manualDiscountAmt: s.manualDiscountAmt,
    vipRate: s.vipRate, vipDiscount: s.vipDiscount,
    pointsUsed: s.pointsUsed, pointsValue: s.pointsValue, pointsEarned: s.pointsEarned,
    payable: s.payable,
    payMethod,
    cashReceived: payMethod === '现金' ? (parseFloat(cashReceived) || s.payable) : null,
    change: payMethod === '现金' ? round2((parseFloat(cashReceived) || s.payable) - s.payable) : null,
    memberId: member ? member.id : null,
    memberName: member ? member.name : null,
    memberLevel: member ? levelName(member.levelId) : null
  };

  // 扣减库存
  cart.forEach(c => {
    const p = state.products.find(x => x.id === c.productId);
    if (p && p.stock >= 0) p.stock = Math.max(0, p.stock - c.qty);
  });
  // 会员积分：扣减使用的积分 + 新增获得积分
  if (member){
    member.points = Math.max(0, member.points - s.pointsUsed) + s.pointsEarned;
  }

  state.sales.push(sale);
  save();
  showReceipt(sale);

  // 清空购物车
  cart = []; cartMemberId = ''; pointsUse = 0; manualDiscount = 100; cashReceived = ''; payMethod = '微信';
  renderPos();
}

/* ---------- 小票 ---------- */
function showReceipt(sale){
  const items = sale.items.map(it => `<div class="r-line"><span>${esc(it.name)} ×${it.qty}</span><span>${money(it.price * it.qty)}</span></div>`).join('');
  $('#receiptContent').innerHTML = `
    <div class="receipt">
      <div class="r-head">
        <div class="shop">${esc(state.shopName)}</div>
        <p>单号：${esc(sale.no)}</p>
        <p>${fmtDT(sale.time)}　收银员：${esc(state.cashier)}</p>
      </div>
      <div class="r-items">${items}</div>
      <div class="r-line"><span>小计</span><span>${money(sale.subtotal)}</span></div>
      ${sale.manualDiscountAmt > 0.001 ? `<div class="r-line"><span>整单折扣</span><span>-${money(sale.manualDiscountAmt)}</span></div>` : ''}
      ${sale.memberName ? `<div class="r-line"><span>${esc(sale.memberName)}（${esc(sale.memberLevel)}）</span><span>-${money(sale.vipDiscount)}</span></div>` : ''}
      ${sale.pointsValue > 0 ? `<div class="r-line"><span>积分抵扣 ${sale.pointsUsed} 分</span><span>-${money(sale.pointsValue)}</span></div>` : ''}
      <div class="r-line r-tot"><span>实收</span><span>${money(sale.payable)}</span></div>
      <div class="r-line"><span>支付方式</span><span>${esc(sale.payMethod)}</span></div>
      ${sale.payMethod === '现金' ? `<div class="r-line"><span>现金 ${money(sale.cashReceived)}　找零</span><span>${money(sale.change)}</span></div>` : ''}
      ${sale.pointsEarned > 0 ? `<p style="margin-top:6px">本次获得积分：${sale.pointsEarned} 分</p>` : ''}
      <p style="text-align:center;margin-top:8px">—— 谢谢惠顾，欢迎再次光临 ——</p>
    </div>`;
  openModal('receiptModal');
}
function printReceipt(){
  $('#printArea').innerHTML = $('#receiptContent').innerHTML;
  window.print();
}

/* ============================================================
 * 商品管理
 * ============================================================ */
let editingProductId = null;
function productFormOpen(id){
  editingProductId = id || null;
  const p = id ? state.products.find(x => x.id === id) : null;
  $('#productModalTitle').textContent = p ? '编辑商品' : '新增商品';
  $('#pfName').value = p ? p.name : '';
  $('#pfCat').value = p ? p.category : '';
  $('#pfPrice').value = p ? p.price : '';
  $('#pfCost').value = p ? p.cost : '';
  $('#pfStock').value = p ? p.stock : 100;
  $('#pfUnit').value = p ? p.unit : '';
  openModal('productModal');
}
function saveProduct(){
  const name = $('#pfName').value.trim();
  const price = parseFloat($('#pfPrice').value);
  if (!name){ alert('请输入商品名称'); return; }
  if (isNaN(price) || price < 0){ alert('请输入正确的售价'); return; }
  const cost = parseFloat($('#pfCost').value) || 0;
  const stock = Math.round(parseFloat($('#pfStock').value) || 0);
  const data = { name, category: $('#pfCat').value.trim() || '未分类', price: round2(price), cost: round2(cost), stock, unit: $('#pfUnit').value.trim() };
  if (editingProductId){
    const p = state.products.find(x => x.id === editingProductId);
    Object.assign(p, data);
  } else {
    state.products.push(Object.assign({ id: uid('p') }, data));
  }
  save(); closeModal('productModal'); renderProducts();
  if (window.__refreshCatList) window.__refreshCatList();
}
function delProduct(id){
  const p = state.products.find(x => x.id === id);
  if (!p) return;
  if (!confirm(`确定删除商品「${p.name}」？历史销售记录不受影响。`)) return;
  state.products = state.products.filter(x => x.id !== id);
  save(); renderProducts();
}
function renderProducts(){
  $('#prodCatFilter').innerHTML = '<option value="全部">全部分类</option>' +
    [...new Set(state.products.map(p => p.category))].map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
  $('#prodCatFilter').value = prodFilter.cat;

  const kw = prodFilter.kw.trim().toLowerCase();
  const list = state.products.filter(p =>
    (prodFilter.cat === '全部' || p.category === prodFilter.cat) &&
    (!kw || p.name.toLowerCase().includes(kw) || p.category.toLowerCase().includes(kw)));

  $('#prodTbody').innerHTML = list.length ? list.map(p => `
    <tr>
      <td><b>${esc(p.name)}</b></td>
      <td><span class="badge b-gray">${esc(p.category)}</span></td>
      <td class="num">${money(p.price)}</td>
      <td class="num" style="color:var(--muted)">${money(p.cost)}</td>
      <td class="num ${p.stock >= 0 && p.stock <= state.settings.lowStock ? 'b-red' : ''}">${p.stock < 0 ? '不限' : p.stock}</td>
      <td>${esc(p.unit || '')}</td>
      <td><button class="btn small" onclick="productFormOpen('${p.id}')">编辑</button>
          <button class="btn small danger" onclick="delProduct('${p.id}')">删除</button></td>
    </tr>`).join('') : '<tr><td colspan="7" class="empty">暂无商品</td></tr>';
}

/* ============================================================
 * 会员管理（含 VIP 等级）
 * ============================================================ */
let memFilter = { kw: '' };

function levelFormOpen(id){
  editingLevelId = id || null;
  const l = id ? state.levels.find(x => x.id === id) : null;
  $('#levelModalTitle').textContent = l ? '编辑等级' : '新增等级';
  $('#lfName').value = l ? l.name : '';
  $('#lfRate').value = l ? l.rate : 0.95;
  openModal('levelModal');
}
function saveLevel(){
  const name = $('#lfName').value.trim();
  const rate = parseFloat($('#lfRate').value);
  if (!name){ alert('请输入等级名称'); return; }
  if (isNaN(rate) || rate <= 0 || rate > 1){ alert('折扣率需在 0.01 ~ 1 之间'); return; }
  if (editingLevelId){
    const l = state.levels.find(x => x.id === editingLevelId);
    l.name = name; l.rate = rate;
  } else {
    state.levels.push({ id: uid('l'), name, rate });
  }
  save(); closeModal('levelModal'); renderMembers();
}
function delLevel(id){
  if (state.levels.length <= 1){ alert('至少保留一个等级'); return; }
  if (state.members.some(m => m.levelId === id)){ alert('该等级下还有会员，无法删除'); return; }
  if (!confirm('确定删除该等级？')) return;
  state.levels = state.levels.filter(x => x.id !== id);
  save(); renderMembers();
}

function memberFormOpen(id){
  editingMemberId = id || null;
  const m = id ? state.members.find(x => x.id === id) : null;
  $('#memberModalTitle').textContent = m ? '编辑会员' : '新增会员';
  $('#mfName').value = m ? m.name : '';
  $('#mfPhone').value = m ? m.phone : '';
  $('#mfPoints').value = m ? m.points : 0;
  $('#mfLevel').innerHTML = state.levels.map(l => `<option value="${l.id}">${esc(l.name)}（${(l.rate * 100).toFixed(0)}折）</option>`).join('');
  $('#mfLevel').value = m ? m.levelId : state.levels[0].id;
  openModal('memberModal');
}
function saveMember(){
  const name = $('#mfName').value.trim();
  if (!name){ alert('请输入会员姓名'); return; }
  const data = {
    name,
    phone: $('#mfPhone').value.trim(),
    levelId: $('#mfLevel').value,
    points: Math.max(0, Math.floor(parseFloat($('#mfPoints').value) || 0))
  };
  if (editingMemberId){
    const m = state.members.find(x => x.id === editingMemberId);
    Object.assign(m, data);
  } else {
    state.members.push(Object.assign({ id: uid('m'), createdAt: Date.now() }, data));
  }
  save(); closeModal('memberModal'); renderMembers();
}
function delMember(id){
  const m = state.members.find(x => x.id === id);
  if (!m) return;
  if (!confirm(`确定删除会员「${m.name}」？历史销售记录不受影响。`)) return;
  state.members = state.members.filter(x => x.id !== id);
  save(); renderMembers();
}
function renderMembers(){
  const levelColor = { 0.98: 'b-blue', 0.95: 'b-green', 0.92: 'b-orange', 0.88: 'b-purple' };
  const lc = l => levelColor[l.rate] || 'b-gray';

  $('#levelTbody').innerHTML = state.levels.map(l => `
    <tr>
      <td><span class="badge ${lc(l)}">${esc(l.name)}</span></td>
      <td><b>${(l.rate * 100).toFixed(0)} 折</b>（率 ${l.rate}）</td>
      <td style="color:var(--muted);font-size:13px">在整单折扣之后额外 ${(l.rate * 100).toFixed(0)} 折</td>
      <td><button class="btn small" onclick="levelFormOpen('${l.id}')">编辑</button>
          <button class="btn small danger" onclick="delLevel('${l.id}')">删除</button></td>
    </tr>`).join('');

  const kw = memFilter.kw.trim().toLowerCase();
  const list = state.members.filter(m => !kw || m.name.toLowerCase().includes(kw) || m.phone.includes(kw));
  $('#memTbody').innerHTML = list.length ? list.map(m => `
    <tr>
      <td><b>${esc(m.name)}</b></td>
      <td>${esc(m.phone || '-')}</td>
      <td><span class="badge ${lc(state.levels.find(l => l.id === m.levelId) || { rate: 1 })}">${esc(levelName(m.levelId))}</span></td>
      <td class="num"><b>${m.points}</b> 分</td>
      <td>${fmtD(m.createdAt)}</td>
      <td><button class="btn small" onclick="memberFormOpen('${m.id}')">编辑</button>
          <button class="btn small danger" onclick="delMember('${m.id}')">删除</button></td>
    </tr>`).join('') : '<tr><td colspan="6" class="empty">暂无会员</td></tr>';
}

/* ============================================================
 * 出账记账
 * ============================================================ */
let editingExpenseId = null;
let expFilter = { cat: '全部', from: '', to: '' };

function expenseFormOpen(id){
  editingExpenseId = id || null;
  const e = id ? state.expenses.find(x => x.id === id) : null;
  $('#expenseModalTitle').textContent = e ? '编辑出账' : '新增出账';
  $('#efDate').value = e ? fmtD(e.time) : todayStr();
  $('#efCat').value = e ? e.category : '进货';
  $('#efAmount').value = e ? e.amount : '';
  $('#efNote').value = e ? e.note : '';
  openModal('expenseModal');
}
function saveExpense(){
  const date = $('#efDate').value;
  const cat = $('#efCat').value.trim();
  const amount = parseFloat($('#efAmount').value);
  if (!date){ alert('请选择日期'); return; }
  if (!cat){ alert('请输入类别'); return; }
  if (isNaN(amount) || amount <= 0){ alert('请输入正确的金额（大于 0）'); return; }
  const data = { time: new Date(date + 'T00:00:00').getTime(), category: cat, amount: round2(amount), note: $('#efNote').value.trim() };
  if (editingExpenseId){
    const e = state.expenses.find(x => x.id === editingExpenseId);
    Object.assign(e, data);
  } else {
    state.expenses.push(Object.assign({ id: uid('e') }, data));
  }
  save(); closeModal('expenseModal'); renderExpenses();
}
function delExpense(id){
  const e = state.expenses.find(x => x.id === id);
  if (!e) return;
  if (!confirm(`确定删除该笔出账（${e.category} ${money(e.amount)}）？`)) return;
  state.expenses = state.expenses.filter(x => x.id !== id);
  save(); renderExpenses();
}
function renderExpenses(){
  const list = state.expenses.filter(e =>
    (expFilter.cat === '全部' || e.category === expFilter.cat) &&
    inRange(e.time, expFilter.from, expFilter.to));
  $('#expTbody').innerHTML = list.length ? list.map(e => `
    <tr>
      <td>${fmtD(e.time)}</td>
      <td><span class="badge b-red">${esc(e.category)}</span></td>
      <td class="num"><b style="color:var(--danger)">${money(e.amount)}</b></td>
      <td style="color:var(--muted)">${esc(e.note || '-')}</td>
      <td><button class="btn small" onclick="expenseFormOpen('${e.id}')">编辑</button>
          <button class="btn small danger" onclick="delExpense('${e.id}')">删除</button></td>
    </tr>`).join('') : '<tr><td colspan="5" class="empty">该条件下暂无出账记录</td></tr>';
  $('#expTotal').textContent = money(list.reduce((a, e) => a + e.amount, 0));
}

/* ============================================================
 * 流水账本
 * ============================================================ */
let ledgerFilter = { type: 'all', from: '', to: '' };
function renderLedger(){
  const rows = [];
  state.sales.forEach(s => {
    if (!inRange(s.time, ledgerFilter.from, ledgerFilter.to)) return;
    if (ledgerFilter.type === 'out') return;
    const first = s.items[0];
    const more = s.items.length > 1 ? ` 等 ${s.items.length} 件` : '';
    rows.push({
      time: s.time, no: s.no, kind: 'in', badge: 'b-green', badgeText: '销售',
      summary: `${esc(first.name)} ×${first.qty}${more}`,
      amount: s.payable, note: s.memberName ? `${s.memberName}（${s.memberLevel}）` : (s.payMethod || '')
    });
  });
  state.expenses.forEach(e => {
    if (!inRange(e.time, ledgerFilter.from, ledgerFilter.to)) return;
    if (ledgerFilter.type === 'in') return;
    rows.push({
      time: e.time, no: 'ZC-' + e.id.slice(2, 8), kind: 'out', badge: 'b-red', badgeText: '出账',
      summary: `${esc(e.category)} 支出`,
      amount: -e.amount, note: esc(e.note || '')
    });
  });
  rows.sort((a, b) => b.time - a.time);

  $('#ledTbody').innerHTML = rows.length ? rows.map(r => `
    <tr>
      <td>${fmtDT(r.time)}</td>
      <td><span class="badge ${r.badge}">${r.badgeText}</span> <span style="font-size:12px;color:var(--muted)">${esc(r.no)}</span></td>
      <td>${r.summary}</td>
      <td class="num" style="color:${r.kind === 'in' ? 'var(--ok)' : 'var(--danger)'};font-weight:600">${r.amount >= 0 ? '+' : '-'}${money(Math.abs(r.amount))}</td>
      <td style="color:var(--muted)">${r.note || '-'}</td>
    </tr>`).join('') : '<tr><td colspan="5" class="empty">该条件下暂无流水</td></tr>';

  const sumIn = round2(rows.filter(r => r.kind === 'in').reduce((a, r) => a + r.amount, 0));
  const sumOut = round2(rows.filter(r => r.kind === 'out').reduce((a, r) => a + Math.abs(r.amount), 0));
  $('#ledSumIn').textContent = money(sumIn);
  $('#ledSumOut').textContent = money(sumOut);
  $('#ledSumNet').textContent = money(sumIn - sumOut);
}

/* ============================================================
 * 统计分析
 * ============================================================ */
let statsRange = { from: todayStr(), to: todayStr() };
function setStatsRange(kind){
  const today = new Date();
  if (kind === 'today'){ statsRange = { from: todayStr(), to: todayStr() }; }
  else if (kind === 'week'){
    const f = new Date(today); f.setDate(f.getDate() - 6);
    statsRange = { from: fmtD(f.getTime()), to: todayStr() };
  }
  else if (kind === 'month'){
    statsRange = { from: `${today.getFullYear()}-${pad(today.getMonth()+1)}-01`, to: todayStr() };
  }
  $('#stFrom').value = statsRange.from;
  $('#stTo').value = statsRange.to;
  renderStats();
}
function renderStats(){
  const { from, to } = statsRange;
  const sales = state.sales.filter(s => inRange(s.time, from, to));
  const exps = state.expenses.filter(e => inRange(e.time, from, to));

  const revenue = round2(sales.reduce((a, s) => a + s.payable, 0));
  const vipGive = round2(sales.reduce((a, s) => a + s.vipDiscount + s.pointsValue, 0));
  const expense = round2(exps.reduce((a, e) => a + e.amount, 0));
  const gross = round2(sales.reduce((a, s) => a + s.items.reduce((x, it) => x + (it.price - it.cost) * it.qty, 0), 0));

  $('#stOrders').textContent = sales.length;
  $('#stRevenue').textContent = money(revenue);
  $('#stVip').textContent = money(vipGive);
  $('#stExpense').textContent = money(expense);
  $('#stGross').textContent = money(gross);
  $('#stNet').textContent = money(round2(gross - expense));

  // 近 7 天营业额柱状图
  const days = [];
  for (let i = 6; i >= 0; i--){
    const d = new Date(); d.setDate(d.getDate() - i);
    const ds = fmtD(d.getTime());
    const v = round2(state.sales.filter(s => inRange(s.time, ds, ds)).reduce((a, s) => a + s.payable, 0));
    days.push({ label: ds.slice(5), value: v });
  }
  const maxV = Math.max(...days.map(d => d.value), 1);
  $('#weekBars').innerHTML = days.map(d => `
    <div class="bar-col" title="${d.label}：${money(d.value)}">
      <div class="bv">${d.value >= 100 ? '¥' + Math.round(d.value) : d.value > 0 ? d.value.toFixed(0) : ''}</div>
      <div class="bar" style="height:${Math.max(3, d.value / maxV * 100)}%"></div>
      <div class="bl">${d.label}</div>
    </div>`).join('');

  // 分类销售占比
  const catMap = {};
  sales.forEach(s => s.items.forEach(it => {
    catMap[it.category] = (catMap[it.category] || 0) + it.price * it.qty;
  }));
  const cats = Object.entries(catMap).sort((a, b) => b[1] - a[1]);
  const maxC = cats.length ? cats[0][1] : 1;
  $('#catBreakdown').innerHTML = cats.length ? cats.map(([c, v]) => `
    <div class="catbar-row">
      <span class="cn">${esc(c)}</span>
      <div class="track"><div class="fill" style="width:${(v / maxC * 100).toFixed(1)}%"></div></div>
      <span class="cv">${money(v)}</span>
    </div>`).join('') : '<div class="empty">该时间段内无销售数据</div>';
}

/* ============================================================
 * 系统设置
 * ============================================================ */
function renderSettings(){
  $('#setShopName').value = state.shopName;
  $('#setCashier').value = state.cashier;
  $('#setPointsPerYuan').value = state.settings.pointsPerYuan;
  $('#setPointsToYuan').value = state.settings.pointsToYuan;
  $('#setLowStock').value = state.settings.lowStock;
}
function saveSettings(){
  const shopName = $('#setShopName').value.trim() || '收银宝便利店';
  state.shopName = shopName;
  state.cashier = $('#setCashier').value.trim() || '收银员';
  state.settings.pointsPerYuan = Math.max(0, parseFloat($('#setPointsPerYuan').value) || 0);
  state.settings.pointsToYuan = Math.max(1, Math.round(parseFloat($('#setPointsToYuan').value) || 100));
  state.settings.lowStock = Math.max(0, Math.round(parseFloat($('#setLowStock').value) || 10));
  save(); renderSettings(); renderHome();
  alert('设置已保存');
}
function exportData(){
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `收银宝备份_${todayStr()}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}
function importData(file){
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try{
      const s = JSON.parse(e.target.result);
      if (!s || !Array.isArray(s.products) || !Array.isArray(s.levels)) throw new Error('bad');
      const def = defaultState();
      const merged = Object.assign({}, def, s);
      merged.settings = Object.assign({}, def.settings, s.settings || {});
      state = merged;
      save();
      alert('导入成功！');
      switchView('home');
    }catch(err){
      alert('导入失败：文件格式不正确');
    }
  };
  reader.readAsText(file);
  $('#importFile').value = '';
}
function clearData(){
  if (!confirm('确定清空所有数据？此操作不可恢复！')) return;
  state = defaultState();
  save();
  switchView('home');
}
function restoreSample(){
  if (!confirm('将用示例数据覆盖当前所有数据，确定？')) return;
  state = defaultState();
  save();
  switchView('home');
}

/* ============================================================
 * 初始化
 * ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  state = load();
  // 首次使用写入示例数据
  if (!localStorage.getItem(LS_KEY)) save();
  // 商品分类 datalist
  const refreshCatList = () => {
    $('#catList').innerHTML = [...new Set(state.products.map(p => p.category))]
      .map(c => `<option value="${esc(c)}">`).join('');
  };
  refreshCatList();
  // 简单的分类列表自动刷新（商品保存后调用）
  window.__refreshCatList = refreshCatList;
  switchView('home');
});
