// 收银宝核心折扣逻辑自测（Node 环境，仅验证纯计算函数）
'use strict';
const fs = require('fs');
const vm = require('vm');

const code = fs.readFileSync('app.js', 'utf8');
const sandbox = { console, Math, Date, Number, String, JSON, Object, Array, parseFloat, isNaN, alert: () => {}, document: { addEventListener: () => {} } };
vm.createContext(sandbox);
vm.runInContext(code, sandbox);
vm.runInContext('state = defaultState();', sandbox); // 初始化默认数据

function setCart(items){ vm.runInContext(`cart = ${JSON.stringify(items)};`, sandbox); }
function setOpts(md, pu){ vm.runInContext(`manualDiscount = ${md}; pointsUse = ${pu};`, sandbox); }
function calcCart(m){ return sandbox.calcCart(m); }

let pass = 0, fail = 0;
function check(name, actual, expected){
  const ok = Math.abs(actual - expected) < 0.001;
  if (ok){ pass++; console.log(`PASS  ${name}  = ${actual}`); }
  else { fail++; console.log(`FAIL  ${name}  期望 ${expected}，实际 ${actual}`); }
}

// --- 场景 1：非会员，不打折 ---
setCart([
  { productId: 'p1', name: '可乐', category: '饮料', price: 3.00, cost: 2.10, qty: 2 },
  { productId: 'p4', name: '薯片', category: '零食', price: 6.00, cost: 3.60, qty: 1 }
]);
setOpts(100, 0);
let s = calcCart(null);
check('非会员小计', s.subtotal, 12);
check('非会员应收', s.payable, 12);
check('非会员VIP折扣', s.vipDiscount, 0);
check('非会员积分获得', s.pointsEarned, 12);

// --- 场景 2：金卡会员 92 折（额外折扣）---
setCart([{ productId: 'p1', name: '可乐', price: 100, cost: 50, qty: 1 }]);
setOpts(100, 0);
const gold = { id: 'm1', name: '张三', levelId: 'l3', points: 500 };
s = calcCart(gold);
check('金卡VIP折扣金额', s.vipDiscount, 8);
check('金卡应收(92折)', s.payable, 92);
check('金卡VIP率', s.vipRate, 0.92);

// --- 场景 3：整单 90 折 + 金卡额外 92 折（额外折扣叠加）---
setOpts(90, 0);
s = calcCart(gold);
check('整单90折后', s.manualDiscountAmt, 10);
check('叠加后VIP折扣(100*0.9*0.08)', s.vipDiscount, 7.2);
check('叠加后应收', s.payable, 82.8);

// --- 场景 4：积分抵扣 500 分（100分=1元），金卡 92 折 ---
setOpts(100, 500);
s = calcCart(gold);
check('积分抵扣金额', s.pointsValue, 5);
check('积分抵扣后应收', s.payable, 87);
check('积分使用数', s.pointsUsed, 500);

// --- 场景 5：积分超过会员持有数，自动截断 ---
setOpts(100, 99999);
s = calcCart(gold); // 会员只有 500 分
check('超额积分截断到500', s.pointsUsed, 500);

// --- 场景 6：积分抵扣上限 50% 折后金额 ---
const whale = { id: 'm9', name: '大户', levelId: 'l4', points: 100000 };
setOpts(100, 99999);
s = calcCart(whale); // 黑金 88 折 → 折后 88，上限 44 元 = 4400 分
check('积分上限截断(4400分)', s.pointsUsed, 4400);
check('积分抵扣44元', s.pointsValue, 44);
check('应收=88-44', s.payable, 44);

// --- 场景 7：黑金会员整单折扣叠加 ---
setOpts(80, 0);
s = calcCart(whale);
check('黑金叠加应收(100*0.8*0.88)', s.payable, 70.4);

console.log(`\n结果：${pass} 通过，${fail} 失败`);
process.exit(fail ? 1 : 0);
